const express = require("express");
const bodyParser = require("body-parser")
var db = require('./database');
var multer  = require('multer');
const imageSizePackage = require('image-size');
// New app using express module
const app = express();
app.use(bodyParser.urlencoded({
  extended:true
}));

app.use(express.static(__dirname + '/'));
app.use('/images', express.static('images'));


/*----------------------------------------- Multer statement for Storage  ---------------------------------*/
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './images')
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname)
    }
});

var fileValidation = (req, file, cb) => {
    if((file.mimetype).includes('jpeg') || (file.mimetype).includes('png') || (file.mimetype).includes('jpg')){
        cb(null, true);
    } else{
        cb(null, false);

    }

};

//var upload = multer({ storage: storage,fileFilter: fileValidation })
var upload = multer({ storage: storage})

/*----------------------------------------------- Set Pages Url Index  -------------------------------------*/
app.get("/", function(req, res) {
res.sendFile(__dirname + "/upload.html");
});

/*----------------------------------------------- Post Request 1 Start  -------------------------------------*/
app.post('/fileupload-process', upload.single('filetoupload'), function (req, res, next) {
    var con = db.conn();

    var personName = req.body.personName;
    if(personName=='')
    {
       res.end("Person Name can not be empty");
    }

    console.log(JSON.stringify(req.file))

      filePath = req.file.path;

     var dimensions = imageSizePackage(filePath);
    console.log(JSON.stringify(dimensions));
      
    imageName   = req.file.filename;
    imageHeight = dimensions.height; 
    imageWidth  = dimensions.width;
    imageSize   = req.file.size;
    imageSize   = Math.floor(imageSize/1024);
    imageExt    = dimensions.type; 

    var response = '<a href="/">Home</a><br>'
    response += "Files uploaded successfully.<br>"
    response += `<h4>Path=> ${filePath} </h4> <h4>Width=> ${imageWidth} </h4> <h4>Height=> ${imageHeight} </h4> <h4>Size=> ${imageSize}KB </h4> <h4>Extension=> ${imageExt} </h4> `
    res.write(response);

    imageLocation = '';

    var sql = "INSERT INTO tblimagesdetails (imageName,imageHeight,imageWidth,imageSize,imageExt,personName,imageLocation) VALUES ('"+imageName+"', '"+imageHeight+"','"+imageWidth+"','"+imageSize+"', '"+imageExt+"','"+personName+"','"+imageLocation+"')";

      con.connect(function(err) {
        if (err) {
          console.log("Database  not Connected!");
          res.end("Database  not Connected!");
        }

        con.query(sql, function (err, result) {
          if (err) {
            console.log (err);
            res.end("Data not saved in Database");
          } 
          else {
            console.log("inserted");
            res.end("Data Saved in Database");
          }
         
        });

    });

});

/*----------------------------------------------- End of File content -------------------------------------*/
app.listen(3009, function(){
console.log("Upload Image Server running on 3009");
})
