 $(document).ready(function() {
   
 });

 function edit(clicked_id)
   {
      //fullId = clicked_id.spilt("-");
      var personName = '';
      var imagePath = '';
      idForUpdate = parseInt(clicked_id);
      $.ajax({
         url:"/get-one-image-detail",
         method:"POST",
         data:{ idForUpdate: idForUpdate,},
         dataType: 'json',
         success:function(data)
         { 
            console.log("Res -> "+data);
            var length = data.length;

            personName = data[0].personName;
            imageName = data[0].imageName;
            imagePath = "/images/"+imageName;

            console.log("P -> "+personName);

            $("#personName2").val(personName);
            $("#imageLink").attr("href",imagePath);
            //$("#filetoupload").val(imagePath);  

             $("#imageIdForUpdate").val(idForUpdate);
            $("#editImageModal").modal('show');
          }

        });

   }

