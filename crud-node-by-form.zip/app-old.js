const express = require("express");
const bodyParser = require("body-parser")
var db = require('./database');
var multer  = require('multer');
const imageSizePackage = require('image-size');
const path = require('path')
//const sweetAlert = require('sweetalert');
// New app using express module
const app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({
  extended:true
}));

app.use(express.static(__dirname + '/'));
app.use('/images', express.static('images'));

app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));

/*----------------------------------------- Multer statement for Storage  ---------------------------------*/
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './images')
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname)
    }
});

var fileValidation = (req, file, cb) => {
    if((file.mimetype).includes('jpeg') || (file.mimetype).includes('png') || (file.mimetype).includes('jpg')){
        cb(null, true);
    } else{
        cb(null, false);

    }

};

//var upload = multer({ storage: storage,fileFilter: fileValidation })
var upload = multer({ storage: storage})

/*----------------------------------------------- Set Pages Url Index  -------------------------------------*/
/*app.get("/", function(req, res) {
res.sendFile(__dirname + "/upload.html");
});*/

/*----------------------------------------------- Get Request 1 Start  -------------------------------------*/
app.get('/', function(req, res) {
     message = ''; 
     alertColor = ""
     getImageList(res,message,alertColor);
});

/*----------------------------------------------- Post Request 2 Start  -------------------------------------*/
app.post('/fileupload-process', upload.single('filetoupload'), function (req, res, next) {
    //var con = db.conn();

    var personName = req.body.personName;
    if(personName=='')
    {
       //return res.redirect('/?err=2');
      message = "Person Name can't be empty "
        alertColor = "alert-danger"
        //return res.render('upload',{message:message,alertColor:alertColor}); 
        getImageList(res,message,alertColor);
    }

    console.log(JSON.stringify(req.file))

      filePath = req.file.path;

     var dimensions = imageSizePackage(filePath);
    console.log(JSON.stringify(dimensions));
      
    imageName   = req.file.filename;
    imageHeight = dimensions.height; 
    imageWidth  = dimensions.width;
    imageSize   = req.file.size;
    imageSize   = Math.floor(imageSize/1024);
    imageExt    = dimensions.type; 

    var response = '<a href="/">Home</a><br>'
    response += "Files uploaded successfully.<br>"
    response += `<h4>Path=> ${filePath} </h4> <h4>Width=> ${imageWidth} </h4> <h4>Height=> ${imageHeight} </h4> <h4>Size=> ${imageSize}KB </h4> <h4>Extension=> ${imageExt} </h4> `
    //res.write(response);

    imageLocation = '';

    var sql = "INSERT INTO tblimagesdetails (imageName,imageHeight,imageWidth,imageSize,imageExt,personName,imageLocation) VALUES ('"+imageName+"', '"+imageHeight+"','"+imageWidth+"','"+imageSize+"', '"+imageExt+"','"+personName+"','"+imageLocation+"')";

    db.query(sql, function (err, result) {
        if (err) {
          console.log (err);
           //return res.redirect('/?err=1');
           message='Something went Wrong'
           alertColor = "alert-danger"
           getImageList(res,message,alertColor);
           //return res.render('upload',{message:'Something went Wrong'});  
        } 
        else {
          console.log("inserted");
          //res.end("inserted");
          //return res.redirect('/?msg=1');
          message = 'Data Saved in Database Properly'
          alertColor = "alert-success"
          getImageList(res,message,alertColor);
          //return res.render('upload',{message:'Data Saved in Database Properly'});  
        }
       
      });

});

/*----------------------------------------------- Get Request 3 Start  -------------------------------------*/
app.get('/delete-image/:id', function (req, res) {
    var imageId = req.params.id;
    var message = ""
    var alertColor = ""
    if(imageId>0)
    {
        var sql = "delete from tblimagesdetails where imageId="+imageId;
        db.query(sql, function (err, result) {
            if (err) {
              console.warn (err);
              message = "Something went Wrong"
              alertColor = "alert-danger"
              //return res.render('upload',{message:message,alertColor:alertColor}); 
            } 
            else {
              console.warn(result);
              //res.end("inserted");
              if(result.affectedRows==0)
              {
                 message = "Invalid Image Id for Delete"
                 alertColor = "alert-danger"
                 //return res.render('upload',{message:message,alertColor:alertColor});
              }

              if(result.affectedRows>0)
              {
                  message = "Image Deleted Successfully"
                  alertColor = "alert-success"
                  //return res.render('upload',{message:message,alertColor:alertColor}); 
              }
            }
           getImageList(res,message,alertColor);
          });
        
        
    }
    else {
        message = "Invalid Image Id for Delete "
        alertColor = "alert-danger"
        //return res.render('upload',{message:message,alertColor:alertColor}); 
        getImageList(res,message,alertColor);
    }
});

/*----------------------------------------------- Post Request 4 Start  -------------------------------------*/
app.post('/edit-process', upload.single('filetoupload'), function (req, res, next) {
    //var con = db.conn();
    var message = ""
    var alertColor = ""

    var imageId = req.body.imageId;
    if(imageId=='')
    {
        message = "Invalid Image Id for update "
        alertColor = "alert-danger"
        //return res.render('upload',{message:message,alertColor:alertColor}); 
        getImageList(res,message,alertColor);
    }

    var personName = req.body.personName;
    if(personName=='')
    {
       //return res.redirect('/?err=2');
       message = "Person Name can't be empty "
        alertColor = "alert-danger"
        //return res.render('upload',{message:message,alertColor:alertColor}); 
        getImageList(res,message,alertColor);
    }

    if(typeof req.file !== 'undefined')
    {
        console.log(JSON.stringify(req.file))

          filePath = req.file.path;

         var dimensions = imageSizePackage(filePath);
        console.log(JSON.stringify(dimensions));
          
        imageName   = req.file.filename;
        imageHeight = dimensions.height; 
        imageWidth  = dimensions.width;
        imageSize   = req.file.size;
        imageSize   = Math.floor(imageSize/1024);
        imageExt    = dimensions.type; 

        var response = '<a href="/">Home</a><br>'
        response += "Files uploaded successfully.<br>"
        response += `<h4>Path=> ${filePath} </h4> <h4>Width=> ${imageWidth} </h4> <h4>Height=> ${imageHeight} </h4> <h4>Size=> ${imageSize}KB </h4> <h4>Extension=> ${imageExt} </h4> `
        //res.write(response);

        imageLocation = '';

        var sql = 'UPDATE tblimagesdetails SET imageName="'+imageName+'",imageHeight='+imageHeight+',imageWidth='+imageWidth+',imageSize='+imageSize+',imageExt="'+imageExt+'",personName="'+personName+'",imageLocation="'+imageLocation+'" WHERE imageId='+imageId+''   
    }

    if(typeof req.file == 'undefined')
    {
        var sql = 'UPDATE tblimagesdetails SET personName="'+personName+'" WHERE imageId='+imageId+''   
    }    
    db.query(sql, function (err, result) {
        if (err) {
          console.warn (err);
          message = "Something went Wrong"
          alertColor = "alert-danger"
          //return res.render('upload',{message:message,alertColor:alertColor}); 
        } 
        else {
          console.warn("Image Updated Successfully");
          //res.end("inserted");
          if(result.affectedRows==0)
          {
             message = "Invalid Image Id for Update"
             alertColor = "alert-danger"
             //return res.render('upload',{message:message,alertColor:alertColor});
          }

          if(result.affectedRows>0)
          {
              message = "Image Updated Successfully"
              alertColor = "alert-success"
              //return res.render('upload',{message:message,alertColor:alertColor}); 
          }
        }
       getImageList(res,message,alertColor);
      });

});

/*----------------------------------------------- Post Request 5 Start  -------------------------------------*/
app.post('/get-one-image-detail',function (req, res) {

 var imageId = req.body.idForUpdate;

 var sql = "select * from tblimagesdetails where imageId="+imageId;
    db.query(sql, function (err, result) {
        if (err) {
          console.warn (err);
          return res.send(err)
          //res.end("not inserted");
          
        } 
        else {
          console.warn("One Image data fetch Properly");
          //res.end("inserted");
           return res.send(result); 
        }
       
      });
    

});


/*----------------------------------------------- Image list function -------------------------------------*/
function getImageList(res,message,alertColor)
{
    var sql = "select * from tblimagesdetails order by imageId desc";
    db.query(sql, function (err, result) {
        if (err) {
          console.warn (err);
        return res.render('upload',{message:message,alertColor:alertColor,data:err});
          //res.end("not inserted");
          
        } 
        else {
          console.warn("fetch data Properly");
          //res.end("inserted");
           return res.render('upload',{message:message,alertColor:alertColor,data:result}); 
        }
       
      });
}

/*----------------------------------------------- End of File content -------------------------------------*/
app.listen(3009, function(){
console.log("Upload Image Server running on 3009");
})
